# -*- coding: utf-8 -*-

class ModuleDocFragment(object):
    DOCUMENTATION = r'''
options: {}
'''